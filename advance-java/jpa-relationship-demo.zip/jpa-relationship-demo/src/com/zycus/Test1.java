package com.zycus;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.zycus.entities.Author;
import com.zycus.entities.Book;

public class Test1 {
	
	public static void main(String[] args)
	{
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("jpa-relationship-demo");
		
		EntityManager em=factory.createEntityManager();
		
		
//		Author a1=new Author("Bhakti", "Padawe", "bio", LocalDate.of(1998, 9, 29),21);
//		Author a2=em.find(Author.class, 1);
//		
//		Book b1 = new Book("book1",  "desc of book 1", 12.2F, "asdfadfa", 100, LocalDate.of(2020, 1, 1),a2);
//		
//		em.getTransaction().begin();
//		em.persist(b1);
//		em.getTransaction().commit();
//		
		Author a1=new Author("Bhakti", "Padawe", "Mumbai", LocalDate.of(1999, 2, 21), 22);
		Author a2=new Author("Sneha", "T", "Mumbai", LocalDate.of(1998, 3, 15), 23);
		Author a3=new Author("Shivani", "M", "Pune", LocalDate.of(1997, 1, 12), 24);
		
		Set<Author> set=new HashSet<>();
		set.add(a1);
		set.add(a2);
		set.add(a3);
		
		Book book1 = new Book("book1",  "desc of book 1", 12.2F, "asdfadfa", 100, LocalDate.of(2020, 1, 1), set );
		
		em.getTransaction().begin();
		em.persist(book1);
		em.getTransaction().commit();
		
		Query query=em.createQuery("SELECT a from Author a WHERE a.bio=:city",Author.class);
		query.setParameter("city", "Mumbai");
		
		List<Author> list=(List<Author>) query.getResultList();
		
		for(Author author:list)
			System.out.println(author);
		
		
	}

}
