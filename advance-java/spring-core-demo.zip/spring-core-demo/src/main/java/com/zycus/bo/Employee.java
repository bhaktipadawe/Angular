package com.zycus.bo;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.context.annotation.Scope;

@Component
@Scope("singleton")
public class Employee implements InitializingBean, DisposableBean {
	
	@Value("ABCD")
	private String ename;
	
	@Value("Mumbai")
	private String city;

	public Employee() {
		
		System.out.println("Employee object is created..");
	}

	public Employee(String ename, String city) {
		super();
		this.ename = ename;
		this.city = city;
	}

	public String getEname() {
		return ename;
	}
	
	public void setEname(String ename) {
		this.ename = ename;
		System.out.println("setting name");
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
		System.out.println("setting city");
	}

	@Override
	public String toString() {
		return "Employee [ename=" + ename + ", city=" + city + "]";
	}

	public void destroy() throws Exception {
		// TODO Auto-generated method stub
		System.out.println("Do something before the object gets destroyed");
		
	}

	public void afterPropertiesSet() throws Exception {
		// TODO Auto-generated method stub
		System.out.println("Do something after setting the properties");
	}
	
	
	
}
