package com.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootJpaDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
