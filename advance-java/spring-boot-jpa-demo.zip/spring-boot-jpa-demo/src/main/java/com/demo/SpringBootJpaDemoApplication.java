package com.demo;

import java.sql.SQLException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.demo.entities.Account;
import com.demo.entities.Reward;
import com.demo.repository.JpaRewardRepositoryImpl;
import com.demo.repository.RewardRepository;
import com.demo.services.BankService;

@SpringBootApplication
public class SpringBootJpaDemoApplication {

	public static void main(String[] args) throws SQLException {
		ApplicationContext context = SpringApplication.run(SpringBootJpaDemoApplication.class, args);
		BankService bankService = context.getBean(BankService.class);
		
		System.out.println(bankService.getAllAccounts());
		
		bankService.transfer(2L, 1L, 10);
		
		System.out.println(bankService.getAllAccounts());
		
		Account account = new Account(1L,"Bhakti", true, 2000, "bhakti29@gmail.com","Mumbai", "India");
		bankService.createNewAccount(account);
		bankService.deActivateAccount(3L);
		
//		Reward reward = new Reward();
//		reward.setAccountNumber(2L);
//		reward.setRewardAmount(100);
//		reward.setRewardConfirmationNumber(111L);
//		
//		RewardRepository rewardRepository = context.getBean(JpaRewardRepositoryImpl.class);
//		rewardRepository.addReward(reward);
		
		
//		System.out.println(rewardRepository.getTotalRewardAmount(2L));
//		System.out.println(rewardRepository.getAllRewardsForAccount(2L));		
		
	}
	}

