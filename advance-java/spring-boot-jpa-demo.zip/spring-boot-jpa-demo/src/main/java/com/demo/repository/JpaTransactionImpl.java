package com.demo.repository;

import java.sql.SQLException;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.demo.entities.TransactionDetail;

@Repository("jpaTransaction")
public class JpaTransactionImpl implements TransactionRepository{

	@PersistenceContext
	private EntityManager em;
	
	@Override
	@Transactional
	public Long addTransaction(TransactionDetail transactionDetail) throws SQLException {
		// TODO Auto-generated method stub
		 em.persist(transactionDetail);
		 return transactionDetail.getTransactionId();
	}
	
	@Transactional
	@Override
	public List<TransactionDetail> getAllTransactionDetailsByAccountNumber(Long accountNumber) throws SQLException {
		// TODO Auto-generated method stub
		Query query = em.createQuery("Select a from TransactionDetail a where a.transactionId=? :t_id",TransactionDetail.class);
		query.setParameter("t_id",accountNumber);
		
		
		return query.getResultList();
	}

}
