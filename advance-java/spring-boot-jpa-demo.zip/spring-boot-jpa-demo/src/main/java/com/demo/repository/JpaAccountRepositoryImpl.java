package com.demo.repository;

public class JpaAccountRepositoryImpl {

}
