module Assg24 {
}