module Assg22 {
}